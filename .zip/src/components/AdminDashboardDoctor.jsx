import React from 'react';
import '../css/AdminDashboardDoctorStyles.css';


import Header from './Header';
import { NavLink } from 'react-router-dom';

function AdminDashboardDoctor() {
  const redirect = () => {
    // Redirect logic here
  };

  return (

    <>
      

      <div className="column-2">

        <div  className='div-19'>
        <Header name='Doctor Management'></Header>
        <div id="createNewButton">
          <button className="div-25" onClick={() => redirect()}><NavLink to='/CreateDoctorAcc'>Create New +</NavLink></button>
        </div>
       
        <div className="div-26">
          <table className="table doctors-table">
            <thead className="thead">
              <tr className="tr">
                <th className="th">Doctor ID</th>
                <th className="th">Name</th>
                <th className="th">Fellowship</th>
                <th className="th">Department</th>
                <th className="th">Actions</th>
              </tr>
            </thead>
            <tbody id="doctorTableBody" className="tbody">
              {/* Doctor rows will be rendered here */}
            </tbody>
          </table>
         
        </div>

        </div>
      </div>

    </>

  );
}

export default AdminDashboardDoctor;
