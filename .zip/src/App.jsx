// import { useState } from 'react'


// import './css/adminlogin.css'
// import AdminLoginPage from './components/AdminLoginPage'
// import AdminDashboardDoctor from './components/AdminDashboardDoctor'
// import PharmacyMangement from './components/PharmacyMangement'
// import PatientRecords from './components/PatientRecords'
// import Billing from './components/Billing'
// import CreateDoctorAccount from './components/CreateDoctorAccount'
// import AdminDoctor from './components/AdminDoctor'
// import { createBrowserRouter , RouterProvider } from 'react-router-dom'
// import SideBar from './components/SideBar'

// function App() {
//   const router = createBrowserRouter([
//     {
//       path: "/AdminDashboardDoctor",
//       element: <AdminDashboardDoctor></AdminDashboardDoctor>,
//     },
//     {
//       path: "/billing",
//       element: <Billing></Billing>,
//     },
//     {
//       path: "/adminDashboaedPatientRecord",
//       element:<PatientRecords></PatientRecords> ,
//     },
//     {
//       path: "/pharmacyMangement",
//       element:<PharmacyMangement></PharmacyMangement>,
//     },


//   ]);
//   return(
//     <>
//     {/* <AdminLoginPage></AdminLoginPage> */}
//     <AdminDashboardDoctor></AdminDashboardDoctor>
//     {/* <PharmacyMangement></PharmacyMangement> */}
//     {/* <PatientRecords></PatientRecords> */}
//     {/* <Billing></Billing> */}
//     {/* <CreateDoctorAccount></CreateDoctorAccount> */}
//     {/* <AdminDoctor></AdminDoctor> */}
//     <RouterProvider router={router} />
//     </>
//   )


// }

// export default App


/////////////////////////////////////gpt work//////////////////////////////////////////////////

// import { createBrowserRouter, RouterProvider } from 'react-router-dom';
// import Layout from './components/Layout';
// import AdminDashboardDoctor from './components/AdminDashboardDoctor';
// import PharmacyMangement from './components/PharmacyMangement';
// import PatientRecords from './components/PatientRecords';
// import Billing from './components/Billing';

// const router = createBrowserRouter([
//   {
//     path: "/",  // You can have a default route if needed
//     element: <Layout />,
//     children: [
//       {
//         path: "AdminDashboardDoctor",
//         element: <AdminDashboardDoctor />,
//       },
//       {
//         path: "billing",
//         element: <Billing />,
//       },
//       {
//         path: "adminDashboardPatientRecord",
//         element: <PatientRecords />,
//       },
//       {
//         path: "pharmacyMangement",
//         element: <PharmacyMangement />,
//       },
//     ],
//   },
// ]);

// function App() {
//   return (
//     <RouterProvider router={router} />
//   );
// }

// export default App;



///////////////////////////////////////////second attempt////////////////////////////////////

// src/App.js
import { BrowserRouter as Router, Routes, Route, BrowserRouter } from 'react-router-dom';
import Layout from './components/Layout';
import AdminDashboardDoctor from './components/AdminDashboardDoctor';
import PharmacyMangement from './components/PharmacyMangement';
import PatientRecords from './components/PatientRecords';
import Billing from './components/Billing';
import CreateDoctorAcc from './components/CreateDoctorAcc';
import AdminLoginPage from './components/AdminLoginPage';
import Setting from './components/Setting';

function App() {
  return (

    <Router>
      {/* <Layout> */}

      
            <Routes>
            <Route path='adminLogin' element={<AdminLoginPage></AdminLoginPage>}/>
            <Route path="/" element={<Layout />}>
            <Route path='adminLogin' element={<AdminLoginPage></AdminLoginPage>}/>
              <Route path="AdminDashboardDoctor/" element={<AdminDashboardDoctor />} />
                <Route path='CreateDoctorAcc' element={CreateDoctorAcc}/>
              <Route path="billing" element={<Billing />} />
              <Route path="adminDashboardPatientRecord" element={<PatientRecords />} />
              <Route path="pharmacyMangement" element={<PharmacyMangement />} />
              <Route path="settings" element={<Setting></Setting>} />
            </Route> 
            </Routes>

         



      {/* </Layout> */}
    </Router>

  );
}

export default App;


