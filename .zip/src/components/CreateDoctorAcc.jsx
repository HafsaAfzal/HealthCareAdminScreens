import React from 'react';
import SideBar from './SideBar';
import Header from './Header';
import DoctorForm from './DoctorForm';
import "../css/CreateDocAcc.css";



const CreateDoctorAcc = () => {
    return (
        <>
     {/* <div className="div">
            <div className="div-2">
               <SideBar></SideBar> */}
        <h1>checking</h1>
                <div className="column-2">
                    <Header name='Create New Doctor Account'></Header>
                    <DoctorForm></DoctorForm>
                    
                </div>
          {/* </div>
        </div> */}

       </> 
    );
};

export default CreateDoctorAcc;
